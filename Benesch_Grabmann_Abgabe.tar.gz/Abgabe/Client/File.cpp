/*
 * File.cpp
 *
 *  Created on: 17.10.2014
 *      Author: Alexander Benesch
 */

#include "File.h"

File::File() {
	// TODO Auto-generated constructor stub
	this->file = NULL;
	this->name = "";
	this->size = 0;
}

File::~File() {
	// TODO Auto-generated destructor stub
}

