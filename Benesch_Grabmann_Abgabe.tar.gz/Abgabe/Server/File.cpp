/*
 * File.cpp
 *
 *  Created on: 15.10.2014
 *      Author: clemens
 */

#include "File.h"

File::File(std::string *name) {
	this->name = name;
}

File::~File() {
	// TODO Auto-generated destructor stub
}

